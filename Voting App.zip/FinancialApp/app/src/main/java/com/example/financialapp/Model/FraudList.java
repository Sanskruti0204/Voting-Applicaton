package com.example.financialapp.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class FraudList {
    @SerializedName("message")
    @Expose
    private String message;
    @SerializedName("fraud List")
    @Expose
    private List<FraudModel> categorylist = null;


    public FraudList(){

    }

    public FraudList(String message, List<FraudModel> categorylist) {
        this.message = message;
        this.categorylist = categorylist;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<FraudModel> getCategorylist() {
        return categorylist;
    }

    public void setCategorylist(List<FraudModel> categorylist) {
        this.categorylist = categorylist;
    }
}

