package com.example.financialapp.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class PublicCompanyList {

    @SerializedName("message")
    @Expose
    private String message;
    @SerializedName("Company detail")
    @Expose
    private List<PublicCompanyModel> categorylist = null;


    public PublicCompanyList(){

    }

    public PublicCompanyList(String message, List<PublicCompanyModel> categorylist) {
        this.message = message;
        this.categorylist = categorylist;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<PublicCompanyModel> getCategorylist() {
        return categorylist;
    }

    public void setCategorylist(List<PublicCompanyModel> categorylist) {
        this.categorylist = categorylist;
    }



}
