package com.example.financialapp;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.financialapp.Api.ApiService;
import com.example.financialapp.Api.RetrofitClient;
import com.example.financialapp.Fregment.SessionManager;
import com.example.financialapp.Model.LoginResponse;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class AdminLogin extends AppCompatActivity {

    EditText idname,idpass;
    Button btnlogin;

    SessionManager sessionManager;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);

        idname = findViewById(R.id.idname);
        idpass = findViewById(R.id.idpass);
        btnlogin = findViewById(R.id.btnlogin);
        sessionManager = new SessionManager(this);

        // Check if the user is already logged in, redirect to DashboardActivity
        if (sessionManager.isLoggedIn()) {
            startActivity(new Intent(AdminLogin.this, AdminHome.class));
            finish();
        }

        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = idname.getText().toString().trim();
                String password = idpass.getText().toString().trim();
                if (TextUtils.isEmpty(username)){
                    idname.setError("Please enter User Name");
                    idname.requestFocus();
                    return;
                }else if (TextUtils.isEmpty(password)){
                    idpass.setError("please enter pssword");
                    idpass.requestFocus();
                    return;
                }else {
                    Adminlogin(username, password);
                }
            }
        });

    }

    private void Adminlogin(String username, String password) {
        if (username.equals("admin") && password.equals("admin")) {
            Intent i = new Intent(AdminLogin.this, AdminHome.class);
            startActivity(i);
            Toast.makeText(this, "Login", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Login Failed", Toast.LENGTH_SHORT).show();
        }
    }
}