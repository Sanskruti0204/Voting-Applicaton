package com.example.financialapp.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class OrderResponse {

    @SerializedName("message")
    @Expose
    private String message;

    public OrderResponse(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}



