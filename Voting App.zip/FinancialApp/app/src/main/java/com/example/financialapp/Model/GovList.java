package com.example.financialapp.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class GovList {
    @SerializedName("message")
    @Expose
    private String message;
    @SerializedName("scheme List")
    @Expose
    private List<GovModel> govModelList = null;


    public GovList(){

    }

    public GovList(String message, List<GovModel> govModelList) {
        this.message = message;
        this.govModelList = govModelList;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<GovModel> getCategorylist() {
        return govModelList;
    }

    public void setCategorylist(List<GovModel> govModelList) {
        this.govModelList = govModelList;
    }
}

