package com.example.financialapp.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class EnquiryResponse {

    @SerializedName("message")
    @Expose
    private String message;

    public EnquiryResponse(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}



