package com.example.financialapp.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class CompanyList {
    @SerializedName("message")
    @Expose
    private String message;
    @SerializedName("Comapny List")
    @Expose
    private List<CompanyModel> categorylist = null;


    public CompanyList(){

    }

    public CompanyList(String message, List<CompanyModel> categorylist) {
        this.message = message;
        this.categorylist = categorylist;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<CompanyModel> getCategorylist() {
        return categorylist;
    }

    public void setCategorylist(List<CompanyModel> categorylist) {
        this.categorylist = categorylist;
    }
}

