package com.example.financialapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.financialapp.Api.RetrofitClient;
import com.example.financialapp.Model.RegisterResponse;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener{



        private EditText idEdtEmail;
        private EditText idEdtPass;


        @SuppressLint("MissingInflatedId")
        @Override
        protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);


        idEdtEmail = findViewById(R.id.idEdtEmail);
        idEdtPass = findViewById(R.id.idEdtPass);

        findViewById(R.id.idBtnReg).setOnClickListener(this);
        findViewById(R.id.login).setOnClickListener(this);

    }

        private void userLogin() {
        String Email = idEdtEmail.getText().toString().trim();
        String Pass = idEdtPass.getText().toString().trim();


        if (Email.isEmpty()) {
            idEdtEmail.setError("Email Is Required");
            idEdtEmail.requestFocus();
            return;
        }


        if (Pass.isEmpty()) {
            idEdtPass.setError("Password No Is Required");
            idEdtPass.requestFocus();
            return;
        }
        if (Pass.length() < 8) {
            idEdtPass.setError("Password Should Be Atleast 8 Character Long");
            idEdtPass.requestFocus();
            return;

        }


        //  Call Signup Api Here...

            retrofit2.Call<RegisterResponse> call = RetrofitClient
                    .getInstance()
                    .getApi()
                    .userSignup(Email,Pass);

            call.enqueue(new Callback<RegisterResponse>() {
                @Override
                public void onResponse(retrofit2.Call<RegisterResponse> call, Response<RegisterResponse> response) {
                    RegisterResponse registerResponse=response.body();
                    System.out.println("REGISTERRESPONSE"+registerResponse.getMessage());

                    if (registerResponse!= null && registerResponse.equals("Not Inserted.")){
                        Toast.makeText(RegisterActivity.this, "Not Inserted", Toast.LENGTH_SHORT).show();


                    }else {
                        Toast.makeText(RegisterActivity.this,"Registration Successfully", Toast.LENGTH_SHORT).show();

                    }

                }

                @Override
                public void onFailure(Call<RegisterResponse> call, Throwable t) {
                    Toast.makeText(RegisterActivity.this,t.getMessage(), Toast.LENGTH_SHORT).show();



                }
        });
    }

        @Override
        public void onClick (View v){
        switch (v.getId()) {
            case R.id.idBtnReg:
                userLogin();
                break;
            case R.id.login:
                startActivity(new Intent(this, LoginActivity.class));

                break;
        }

    }}