package com.example.financialapp.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class CountList {

    @SerializedName("message")
    @Expose
    private String message;
    @SerializedName("Vote  detail")
    @Expose
    private List<CountResponse> categorylist = null;

    public CountList() {

    }

    public CountList(String message, List<CountResponse> categorylist) {
        this.message = message;
        this.categorylist = categorylist;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<CountResponse> getCategorylist() {
        return categorylist;
    }

    public void setCategorylist(List<CountResponse> categorylist) {
        this.categorylist = categorylist;
    }
}
