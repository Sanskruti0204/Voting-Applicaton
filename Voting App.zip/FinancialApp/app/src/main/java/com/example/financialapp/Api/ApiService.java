package com.example.financialapp.Api;


import com.example.financialapp.Model.CompanyList;
import com.example.financialapp.Model.CountList;
import com.example.financialapp.Model.EnquiryResponse;
import com.example.financialapp.Model.FraudList;
import com.example.financialapp.Model.GovList;
import com.example.financialapp.Model.LoginResponse;
import com.example.financialapp.Model.OrderResponse;
import com.example.financialapp.Model.PrivateCompanyList;
import com.example.financialapp.Model.PublicCompanyList;
import com.example.financialapp.Model.RegisterResponse;
import com.example.financialapp.Model.UserLoginResponse;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface ApiService {


    @FormUrlEncoded
    @POST("registration.php")
    Call<RegisterResponse> userSignup(
            @Field("email") String Email,
            @Field("password") String Pass
    );
    @FormUrlEncoded
    @POST("add_enqiry.php")
    Call<EnquiryResponse> userSignup(
            @Field("name") String Name,
            @Field("email") String Email,
            @Field("mobile_no") String Pass,
            @Field("question") String Question
    );


    @FormUrlEncoded
    @POST("login.php")
    Call<UserLoginResponse> userLogin(
            @Field("email") String email ,
            @Field("password") String password
    );
    @GET("admincount.php")
    Call<CountList> getcount();

    @FormUrlEncoded
    @POST("admin.php")
    Call<LoginResponse> AdminLogin(
            @Field("username") String username,
            @Field("password") String password
    );
    @FormUrlEncoded
    @POST("vote.php")
    Call<OrderResponse> addOrder(
            @Field("name") String name

    );
    @GET("view_company.php")
    Call<CompanyList> getallcategories();

    @GET("private_company.php")
    Call<PrivateCompanyList>getcompany();

    @GET("public_company.php")
    Call<PublicCompanyList>getallcompany();
    @GET("view_fraud.php")
    Call<FraudList> getallfraud();

    @GET("view_gov_scheme.php")
    Call<GovList> getallscheme();











}
