package com.example.financialapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.financialapp.Api.RetrofitClient;
import com.example.financialapp.Fregment.SessionManager;
import com.example.financialapp.Model.LoginResponse;
import com.example.financialapp.Model.UserLoginResponse;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText idEdtUserName;
    private EditText idEdtPassword;
    Button idBtnLogin;
    SessionManager sessionManager ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getSupportActionBar().hide();

        idEdtUserName = findViewById(R.id.idEdtUserName);
        idEdtPassword = findViewById(R.id.idEdtPassword);
        idBtnLogin = findViewById(R.id.idBtnLogin);
        findViewById(R.id.register).setOnClickListener(this);
        sessionManager = new SessionManager(this);

        idBtnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                userLogin();
            }
        });
        // Check if the user is already logged in, redirect to DashboardActivity
        if (sessionManager.isLoggedIn()) {
            startActivity(new Intent(LoginActivity.this, Voting.class));
            finish();
        }

    }

    private void userLogin() {
        String Email = idEdtUserName.getText().toString().trim();
        String Password = idEdtPassword.getText().toString().trim();

        if (Email.isEmpty()) {
            idEdtUserName.setError("Email Is Required");
            idEdtUserName.requestFocus();
            return;
        }
        if (Password.isEmpty()) {
            idEdtPassword.setError("Password Is Required");
            idEdtPassword.requestFocus();
            return;
        }
        if (Password.length() < 8) {
            idEdtPassword.setError("Password Should Be Atleast 8 Character Long");
            idEdtPassword.requestFocus();
            return;

        }

        Call<UserLoginResponse> call = RetrofitClient
                .getInstance()
                .getApi()
                .userLogin(Email,Password);

        call.enqueue(new Callback<UserLoginResponse>() {
            @Override
            public void onResponse(Call<UserLoginResponse> call, Response<UserLoginResponse> response) {
                UserLoginResponse loginResponse = response.body();
                System.out.println("LOGINRESPONSE" + loginResponse.getMessage());


                if (loginResponse.getMessage().equals("user not found.")) {
                    Toast.makeText(LoginActivity.this, "User Not Found", Toast.LENGTH_SHORT).show();


                } else {
                    Toast.makeText(LoginActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                    sessionManager.putStringData("Pass",loginResponse.getPassword());
                    sessionManager.putStringData("Email",loginResponse.getEmail());
                    sessionManager.setLoggedIn(true);//login
                    Intent i = new Intent(LoginActivity.this, Voting.class);
                    startActivity(i);
                    finish();

                }
            }

            @Override
            public void onFailure(Call<UserLoginResponse> call, Throwable t) {
                Toast.makeText(LoginActivity.this,t.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });
    }

    @Override
    public void onClick (View v){
        switch (v.getId()) {

            case R.id.register:
                startActivity(new Intent(this, RegisterActivity.class));
                break;
        }

    }
}


