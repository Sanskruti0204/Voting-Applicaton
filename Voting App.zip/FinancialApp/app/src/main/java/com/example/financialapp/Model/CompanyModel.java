package com.example.financialapp.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class CompanyModel implements Serializable {

    @SerializedName("message")
    @Expose
    private String message;

    @SerializedName("id")
    @Expose
    private String pkId;

    @SerializedName("company_name")
    @Expose
    private String category_name;

    @SerializedName("criteria")
    @Expose
    private String c_photo;

    @SerializedName("category")
    @Expose
    private String email;



    public CompanyModel() {

    }

    public CompanyModel(String message, String pkId, String category_name, String c_photo, String email, String address, String mobile, String description) {
        this.message = message;
        this.pkId = pkId;
        this.category_name = category_name;
        this.c_photo = c_photo;
        this.email = email;


    }


    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getPkId() {
        return pkId;
    }

    public void setPkId(String pkId) {
        this.pkId = pkId;
    }

    public String getCategory_name() {
        return category_name;
    }

    public void setCategory_name(String category_name) {
        this.category_name = category_name;
    }

    public String getC_photo() {
        return c_photo;
    }

    public void setC_photo(String c_photo) {
        this.c_photo = c_photo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }


}


