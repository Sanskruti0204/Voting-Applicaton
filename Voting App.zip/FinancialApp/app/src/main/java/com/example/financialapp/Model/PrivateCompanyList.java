package com.example.financialapp.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class PrivateCompanyList {

    @SerializedName("message")
    @Expose
    private String message;
    @SerializedName("Company detail")
    @Expose
    private List<PrivateCompanyModel> categorylist = null;


    public PrivateCompanyList(){

    }

    public PrivateCompanyList(String message, List<PrivateCompanyModel> categorylist) {
        this.message = message;
        this.categorylist = categorylist;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<PrivateCompanyModel> getCategorylist() {
        return categorylist;
    }

    public void setCategorylist(List<PrivateCompanyModel> categorylist) {
        this.categorylist = categorylist;
    }
}
