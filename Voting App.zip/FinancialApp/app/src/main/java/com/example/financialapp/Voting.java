package com.example.financialapp;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.financialapp.Api.RetrofitClient;
import com.example.financialapp.Fregment.SessionManager;
import com.example.financialapp.Model.OrderResponse;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
public class Voting extends AppCompatActivity {
    Button btnvote;
    CheckBox checkBox1, checkBox2, checkBox3, checkBox4;
    RadioGroup radioGroup;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_logout, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_settings:
                new AlertDialog.Builder(Voting.this)
                        .setTitle("Confirmation !")
                        .setMessage("Are you sure you want to logout ?")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // Continue with logout operation

                                // Assuming you have a SessionManager class
                                SessionManager sessionManager = new SessionManager(getApplicationContext());

                                // Clear the session and redirect to the login screen
                                sessionManager.logoutUser();

                                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                                startActivity(intent);
                                Toast.makeText(Voting.this, "Logout Successfully", Toast.LENGTH_SHORT).show();
                                finish();
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                            }
                        })
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .show();
                return true; // Added this line to handle the case
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_voting);

        radioGroup = findViewById(R.id.radioGroup);
        btnvote = findViewById(R.id.btnvote);

        btnvote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedId = radioGroup.getCheckedRadioButtonId();
                if (selectedId != -1) {
                    RadioButton selectedRadioButton = findViewById(selectedId);
                    String selectedText = selectedRadioButton.getText().toString();
                    sendVoteToServer(selectedText);

                    // Initiate logout after 3 seconds
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            logoutUser();
                        }
                    }, 3000);

                } else {
                    Toast.makeText(Voting.this, "Please select an option", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void sendVoteToServer(String selectedText) {
        // Call Retrofit API here..
        Call<OrderResponse> call = RetrofitClient
                .getInstance()
                .getApi()
                .addOrder(selectedText);
        call.enqueue(new Callback<OrderResponse>() {
            @Override
            public void onResponse(Call<OrderResponse> call, Response<OrderResponse> response) {
                OrderResponse orderResponse = response.body();
                if (orderResponse != null && orderResponse.equals("NOT INSERTED")) {
                    Toast.makeText(Voting.this, "Not Inserted", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(Voting.this, "Vote Successfully Placed", Toast.LENGTH_SHORT).show();
                    radioGroup.clearCheck(); // Clear the radio button selection
                }
            }

            @Override
            public void onFailure(Call<OrderResponse> call, Throwable t) {
                Toast.makeText(Voting.this, "Vote Successfully Placed", Toast.LENGTH_SHORT).show();
                radioGroup.clearCheck(); // Clear the radio button selection on failure as well
            }
        });
    }

    private void logoutUser() {
        // Assuming you have a SessionManager class
        SessionManager sessionManager = new SessionManager(getApplicationContext());

        // Clear the session and redirect to the login screen
        sessionManager.logoutUser();

        Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
        startActivity(intent);
        Toast.makeText(Voting.this, "Logout Successfully", Toast.LENGTH_SHORT).show();
        finish();
    }
}