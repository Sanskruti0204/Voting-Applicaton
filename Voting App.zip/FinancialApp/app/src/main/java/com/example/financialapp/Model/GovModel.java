package com.example.financialapp.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class GovModel implements Serializable {

    @SerializedName("message")
    @Expose
    private String message;

    @SerializedName("id")
    @Expose
    private String pkId;

    @SerializedName("scheme_name")
    @Expose
    private String category_name;

    @SerializedName("description")
    @Expose
    private String description;

    @SerializedName("official_link")
    @Expose
    private String link;



    public GovModel() {

    }

    public GovModel(String message, String pkId, String category_name, String c_photo, String email, String mobile, String description , String link) {
        this.message = message;
        this.pkId = pkId;
        this.category_name = category_name;
        this.description = description;
        this.link = link
        ;

    }


    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getPkId() {
        return pkId;
    }

    public void setPkId(String pkId) {
        this.pkId = pkId;
    }

    public String getCategory_name() {
        return category_name;
    }

    public void setCategory_name(String category_name) {
        this.category_name = category_name;
    }




    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;

    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;

    }



}


