package com.example.financialapp.Api;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitClient {

/*
    public static final String BASE_URL = "https://demo.ayaminteractive.com/Home%20Restoration%20app/Android/";
*/
    public static final String BASE_URL = "https://projects.ayaminteractive.com/financial/Android/";
    private static RetrofitClient mInstance;
    private static Retrofit retrofit;


    private RetrofitClient(){
        retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

    }

    public static synchronized RetrofitClient getInstance(){
        if (mInstance == null ){
            mInstance = new RetrofitClient();
        }
        return mInstance;

    }

    public ApiService getApi(){
        return retrofit.create(ApiService.class);
    }

}






