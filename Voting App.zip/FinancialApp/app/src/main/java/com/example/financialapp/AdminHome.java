package com.example.financialapp;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.financialapp.Api.ApiService;
import com.example.financialapp.Api.RetrofitClient;
import com.example.financialapp.Fregment.SessionManager;
import com.example.financialapp.Model.CountList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class AdminHome extends AppCompatActivity {

    TextView can1, can2, can3, can4;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_logout, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_settings:
                new AlertDialog.Builder(AdminHome.this)
                        .setTitle("Confirmation !")
                        .setMessage("Are you sure you want to logout ?")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // Continue with logout operation

                                // Assuming you have a SessionManager class
                                SessionManager sessionManager = new SessionManager(getApplicationContext());

                                // Clear the session and redirect to the login screen
                                sessionManager.logoutUser();

                                Intent intent = new Intent(getApplicationContext(), AdminLogin.class);
                                startActivity(intent);
                                Toast.makeText(AdminHome.this, "Logout Successfully", Toast.LENGTH_SHORT).show();
                                finish();
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                            }
                        })
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_home);

        can1 = findViewById(R.id.can1);
        can2 = findViewById(R.id.can2);
        can3 = findViewById(R.id.can3);
        can4 = findViewById(R.id.can4);

        getCount();
    }

    private void getCount() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(RetrofitClient.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        ApiService api = retrofit.create(ApiService.class);

        api.getcount().enqueue(new Callback<CountList>() {
            @Override
            public void onResponse(Call<CountList> call, Response<CountList> response) {
                if (response.isSuccessful()) {
                    CountList countList = response.body();

                    if (countList != null) {
                        int size = countList.getCategorylist().size();
                        // Assuming getCategorylist returns a List<SomeCategory>
                        can1.setText(String.valueOf(size > 0 ? countList.getCategorylist().get(0).getCount() : 0));
                        can2.setText(String.valueOf(size > 1 ? countList.getCategorylist().get(1).getCount() : 0));
                        can3.setText(String.valueOf(size > 2 ? countList.getCategorylist().get(2).getCount() : 0));
                        can4.setText(String.valueOf(size > 3 ? countList.getCategorylist().get(3).getCount() : 0));
                    }
                }
            }

            @Override
            public void onFailure(Call<CountList> call, Throwable t) {
                // Handle failure
            }
        });
    }
}
