package com.example.financialapp.Model;



public class MessageModal {


    // string to store our message and sender

    private String message;

    private String sender;

    public String getCnt() {
        return cnt;
    }

    public void setCnt(String cnt) {
        this.cnt = cnt;
    }

    private String cnt;

    public MessageModal(String message, String sender, String cnt) {
        this.message = message;
        this.sender = sender;
        this.cnt = cnt;
    }
// constructor.

    public MessageModal(String message, String sender) {

        this.message = message;

        this.sender = sender;

    }


    // getter and setter methods.

    public String getMessage() {

        return message;

    }


    public void setMessage(String message) {

        this.message = message;

    }


    public String getSender() {

        return sender;

    }


    public void setSender(String sender) {

        this.sender = sender;

    }
}