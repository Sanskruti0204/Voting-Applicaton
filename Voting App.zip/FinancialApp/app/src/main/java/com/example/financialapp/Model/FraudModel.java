package com.example.financialapp.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class FraudModel implements Serializable {

    @SerializedName("message")
    @Expose
    private String message;

    @SerializedName("id")
    @Expose
    private String pkId;

    @SerializedName("question")
    @Expose
    private String question;

    @SerializedName("description")
    @Expose
    private String descp;

    @SerializedName("image")
    @Expose
    private String c_photo;

    @SerializedName("avoid")
    @Expose
    private String avoid;



    public FraudModel() {

    }

    public FraudModel(String message, String pkId, String question, String descp, String avoid, String c_photo) {
        this.message = message;
        this.pkId = pkId;
        this.question = question;
        this.c_photo = c_photo;
        this.descp = descp;
        this.avoid = avoid;


    }


    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getPkId() {
        return pkId;
    }

    public void setPkId(String pkId) {
        this.pkId = pkId;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getDescp() {
        return descp;
    }

    public void setDescp(String descp) {
        this.descp = descp;
    }

    public String getC_photo() {
        return c_photo;
    }

    public void setC_photo(String c_photo) {
        this.c_photo = c_photo;
    }

    public String getAvoid() {
        return avoid;
    }

    public void setAvoid(String avoid) {
        this.avoid = avoid;
    }
}


