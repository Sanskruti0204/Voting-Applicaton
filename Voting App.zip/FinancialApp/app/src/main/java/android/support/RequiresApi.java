package android.support;

public @interface RequiresApi {
    int api();
}
